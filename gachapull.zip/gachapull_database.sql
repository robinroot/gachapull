--
-- PostgreSQL database dump
--

\restrict Gi5x4V2vjqYd2wgLgyjUzHPvTiOV9ol701peGiBhqMyqALHvbSydBvBFa2oVV16

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: balance_transaction_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.balance_transaction_type AS ENUM (
    'topup',
    'gacha_pull',
    'buyback',
    'refund',
    'adjustment'
);


--
-- Name: coin_transaction_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.coin_transaction_type AS ENUM (
    'credit',
    'debit'
);


--
-- Name: franchise; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.franchise AS ENUM (
    'pokemon',
    'onepiece'
);


--
-- Name: payment_method; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.payment_method AS ENUM (
    'stripe',
    'midtrans',
    'usdt'
);


--
-- Name: payment_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.payment_status AS ENUM (
    'pending',
    'completed',
    'failed'
);


--
-- Name: physical_request_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.physical_request_status AS ENUM (
    'pending',
    'processing',
    'shipped',
    'delivered',
    'cancelled'
);


--
-- Name: rarity; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.rarity AS ENUM (
    'common',
    'rare',
    'super_rare',
    'ultra_rare',
    'legendary'
);


--
-- Name: role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.role AS ENUM (
    'user',
    'admin'
);


--
-- Name: topup_method; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.topup_method AS ENUM (
    'qris',
    'gopay',
    'ovo',
    'dana',
    'bank_transfer'
);


--
-- Name: topup_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.topup_status AS ENUM (
    'pending',
    'completed',
    'failed',
    'expired'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: balance_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.balance_transactions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    amount_idr integer NOT NULL,
    type public.balance_transaction_type NOT NULL,
    description text NOT NULL,
    reference_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: balance_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.balance_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: balance_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.balance_transactions_id_seq OWNED BY public.balance_transactions.id;


--
-- Name: card_buybacks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.card_buybacks (
    id integer NOT NULL,
    user_id integer NOT NULL,
    card_id integer NOT NULL,
    coins_refunded integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    amount_idr integer DEFAULT 0 NOT NULL
);


--
-- Name: card_buybacks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.card_buybacks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: card_buybacks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.card_buybacks_id_seq OWNED BY public.card_buybacks.id;


--
-- Name: cards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cards (
    id integer NOT NULL,
    name text NOT NULL,
    franchise public.franchise NOT NULL,
    rarity public.rarity NOT NULL,
    image_url text NOT NULL,
    description text,
    pull_count integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: cards_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cards_id_seq OWNED BY public.cards.id;


--
-- Name: coin_packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.coin_packages (
    id integer NOT NULL,
    name text NOT NULL,
    coins integer NOT NULL,
    price_usd numeric(10,2) NOT NULL,
    bonus_coins integer DEFAULT 0,
    is_popular boolean DEFAULT false,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: coin_packages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.coin_packages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: coin_packages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.coin_packages_id_seq OWNED BY public.coin_packages.id;


--
-- Name: coin_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.coin_transactions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    amount integer NOT NULL,
    type public.coin_transaction_type NOT NULL,
    description text NOT NULL,
    reference_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: coin_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.coin_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: coin_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.coin_transactions_id_seq OWNED BY public.coin_transactions.id;


--
-- Name: gacha_pulls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gacha_pulls (
    id integer NOT NULL,
    user_id integer NOT NULL,
    pack_id integer NOT NULL,
    card_id integer NOT NULL,
    pulled_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: gacha_pulls_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gacha_pulls_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gacha_pulls_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gacha_pulls_id_seq OWNED BY public.gacha_pulls.id;


--
-- Name: pack_cards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pack_cards (
    id integer NOT NULL,
    pack_id integer NOT NULL,
    card_id integer NOT NULL,
    probability numeric(10,6) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: pack_cards_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pack_cards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pack_cards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pack_cards_id_seq OWNED BY public.pack_cards.id;


--
-- Name: packs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.packs (
    id integer NOT NULL,
    name text NOT NULL,
    franchise public.franchise NOT NULL,
    price_coins integer NOT NULL,
    price_usd numeric(10,2),
    image_url text NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    price_idr integer DEFAULT 15000 NOT NULL
);


--
-- Name: packs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.packs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: packs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.packs_id_seq OWNED BY public.packs.id;


--
-- Name: payment_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_orders (
    id integer NOT NULL,
    user_id integer NOT NULL,
    coin_package_id integer,
    amount_usd numeric(10,2) NOT NULL,
    coins_granted integer NOT NULL,
    method public.payment_method NOT NULL,
    status public.payment_status DEFAULT 'pending'::public.payment_status NOT NULL,
    payment_ref text,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: payment_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payment_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payment_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payment_orders_id_seq OWNED BY public.payment_orders.id;


--
-- Name: payment_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_settings (
    id integer NOT NULL,
    key text NOT NULL,
    value text NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: payment_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payment_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payment_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payment_settings_id_seq OWNED BY public.payment_settings.id;


--
-- Name: physical_card_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.physical_card_requests (
    id integer NOT NULL,
    user_id integer NOT NULL,
    card_id integer NOT NULL,
    status public.physical_request_status DEFAULT 'pending'::public.physical_request_status NOT NULL,
    full_name text NOT NULL,
    phone text NOT NULL,
    address text NOT NULL,
    city text NOT NULL,
    province text NOT NULL,
    postal_code text NOT NULL,
    country text DEFAULT 'Indonesia'::text NOT NULL,
    tracking_number text,
    admin_notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: physical_card_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.physical_card_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: physical_card_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.physical_card_requests_id_seq OWNED BY public.physical_card_requests.id;


--
-- Name: topup_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.topup_orders (
    id integer NOT NULL,
    user_id integer NOT NULL,
    amount_idr integer NOT NULL,
    method public.topup_method NOT NULL,
    status public.topup_status DEFAULT 'pending'::public.topup_status NOT NULL,
    payment_ref text,
    snap_token text,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: topup_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.topup_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: topup_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.topup_orders_id_seq OWNED BY public.topup_orders.id;


--
-- Name: user_balance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_balance (
    user_id integer NOT NULL,
    balance_idr integer DEFAULT 0 NOT NULL,
    total_topup integer DEFAULT 0 NOT NULL,
    total_spent integer DEFAULT 0 NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: user_coins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_coins (
    user_id integer NOT NULL,
    balance integer DEFAULT 0 NOT NULL,
    total_earned integer DEFAULT 0 NOT NULL,
    total_spent integer DEFAULT 0 NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: user_collection; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_collection (
    id integer NOT NULL,
    user_id integer NOT NULL,
    card_id integer NOT NULL,
    count integer DEFAULT 1 NOT NULL,
    first_obtained_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: user_collection_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_collection_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_collection_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_collection_id_seq OWNED BY public.user_collection.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    role public.role DEFAULT 'user'::public.role NOT NULL,
    avatar_url text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: balance_transactions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.balance_transactions ALTER COLUMN id SET DEFAULT nextval('public.balance_transactions_id_seq'::regclass);


--
-- Name: card_buybacks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card_buybacks ALTER COLUMN id SET DEFAULT nextval('public.card_buybacks_id_seq'::regclass);


--
-- Name: cards id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cards ALTER COLUMN id SET DEFAULT nextval('public.cards_id_seq'::regclass);


--
-- Name: coin_packages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coin_packages ALTER COLUMN id SET DEFAULT nextval('public.coin_packages_id_seq'::regclass);


--
-- Name: coin_transactions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coin_transactions ALTER COLUMN id SET DEFAULT nextval('public.coin_transactions_id_seq'::regclass);


--
-- Name: gacha_pulls id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gacha_pulls ALTER COLUMN id SET DEFAULT nextval('public.gacha_pulls_id_seq'::regclass);


--
-- Name: pack_cards id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pack_cards ALTER COLUMN id SET DEFAULT nextval('public.pack_cards_id_seq'::regclass);


--
-- Name: packs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.packs ALTER COLUMN id SET DEFAULT nextval('public.packs_id_seq'::regclass);


--
-- Name: payment_orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_orders ALTER COLUMN id SET DEFAULT nextval('public.payment_orders_id_seq'::regclass);


--
-- Name: payment_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_settings ALTER COLUMN id SET DEFAULT nextval('public.payment_settings_id_seq'::regclass);


--
-- Name: physical_card_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.physical_card_requests ALTER COLUMN id SET DEFAULT nextval('public.physical_card_requests_id_seq'::regclass);


--
-- Name: topup_orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.topup_orders ALTER COLUMN id SET DEFAULT nextval('public.topup_orders_id_seq'::regclass);


--
-- Name: user_collection id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_collection ALTER COLUMN id SET DEFAULT nextval('public.user_collection_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: balance_transactions balance_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.balance_transactions
    ADD CONSTRAINT balance_transactions_pkey PRIMARY KEY (id);


--
-- Name: card_buybacks card_buybacks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card_buybacks
    ADD CONSTRAINT card_buybacks_pkey PRIMARY KEY (id);


--
-- Name: cards cards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cards
    ADD CONSTRAINT cards_pkey PRIMARY KEY (id);


--
-- Name: coin_packages coin_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coin_packages
    ADD CONSTRAINT coin_packages_pkey PRIMARY KEY (id);


--
-- Name: coin_transactions coin_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coin_transactions
    ADD CONSTRAINT coin_transactions_pkey PRIMARY KEY (id);


--
-- Name: gacha_pulls gacha_pulls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gacha_pulls
    ADD CONSTRAINT gacha_pulls_pkey PRIMARY KEY (id);


--
-- Name: pack_cards pack_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pack_cards
    ADD CONSTRAINT pack_cards_pkey PRIMARY KEY (id);


--
-- Name: packs packs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.packs
    ADD CONSTRAINT packs_pkey PRIMARY KEY (id);


--
-- Name: payment_orders payment_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_orders
    ADD CONSTRAINT payment_orders_pkey PRIMARY KEY (id);


--
-- Name: payment_settings payment_settings_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_settings
    ADD CONSTRAINT payment_settings_key_unique UNIQUE (key);


--
-- Name: payment_settings payment_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_settings
    ADD CONSTRAINT payment_settings_pkey PRIMARY KEY (id);


--
-- Name: physical_card_requests physical_card_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.physical_card_requests
    ADD CONSTRAINT physical_card_requests_pkey PRIMARY KEY (id);


--
-- Name: topup_orders topup_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.topup_orders
    ADD CONSTRAINT topup_orders_pkey PRIMARY KEY (id);


--
-- Name: user_balance user_balance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_balance
    ADD CONSTRAINT user_balance_pkey PRIMARY KEY (user_id);


--
-- Name: user_coins user_coins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_coins
    ADD CONSTRAINT user_coins_pkey PRIMARY KEY (user_id);


--
-- Name: user_collection user_collection_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_collection
    ADD CONSTRAINT user_collection_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: balance_transactions balance_transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.balance_transactions
    ADD CONSTRAINT balance_transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: card_buybacks card_buybacks_card_id_cards_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card_buybacks
    ADD CONSTRAINT card_buybacks_card_id_cards_id_fk FOREIGN KEY (card_id) REFERENCES public.cards(id);


--
-- Name: card_buybacks card_buybacks_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.card_buybacks
    ADD CONSTRAINT card_buybacks_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: coin_transactions coin_transactions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coin_transactions
    ADD CONSTRAINT coin_transactions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: gacha_pulls gacha_pulls_card_id_cards_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gacha_pulls
    ADD CONSTRAINT gacha_pulls_card_id_cards_id_fk FOREIGN KEY (card_id) REFERENCES public.cards(id);


--
-- Name: gacha_pulls gacha_pulls_pack_id_packs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gacha_pulls
    ADD CONSTRAINT gacha_pulls_pack_id_packs_id_fk FOREIGN KEY (pack_id) REFERENCES public.packs(id);


--
-- Name: gacha_pulls gacha_pulls_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gacha_pulls
    ADD CONSTRAINT gacha_pulls_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: pack_cards pack_cards_card_id_cards_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pack_cards
    ADD CONSTRAINT pack_cards_card_id_cards_id_fk FOREIGN KEY (card_id) REFERENCES public.cards(id) ON DELETE CASCADE;


--
-- Name: pack_cards pack_cards_pack_id_packs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pack_cards
    ADD CONSTRAINT pack_cards_pack_id_packs_id_fk FOREIGN KEY (pack_id) REFERENCES public.packs(id) ON DELETE CASCADE;


--
-- Name: payment_orders payment_orders_coin_package_id_coin_packages_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_orders
    ADD CONSTRAINT payment_orders_coin_package_id_coin_packages_id_fk FOREIGN KEY (coin_package_id) REFERENCES public.coin_packages(id);


--
-- Name: payment_orders payment_orders_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_orders
    ADD CONSTRAINT payment_orders_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: physical_card_requests physical_card_requests_card_id_cards_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.physical_card_requests
    ADD CONSTRAINT physical_card_requests_card_id_cards_id_fk FOREIGN KEY (card_id) REFERENCES public.cards(id);


--
-- Name: physical_card_requests physical_card_requests_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.physical_card_requests
    ADD CONSTRAINT physical_card_requests_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: topup_orders topup_orders_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.topup_orders
    ADD CONSTRAINT topup_orders_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_balance user_balance_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_balance
    ADD CONSTRAINT user_balance_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_coins user_coins_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_coins
    ADD CONSTRAINT user_coins_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_collection user_collection_card_id_cards_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_collection
    ADD CONSTRAINT user_collection_card_id_cards_id_fk FOREIGN KEY (card_id) REFERENCES public.cards(id);


--
-- Name: user_collection user_collection_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_collection
    ADD CONSTRAINT user_collection_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict Gi5x4V2vjqYd2wgLgyjUzHPvTiOV9ol701peGiBhqMyqALHvbSydBvBFa2oVV16

--
-- PostgreSQL database dump
--

\restrict m4rwdk9gQKIxPt7XCcQDyJ6N1HH6Yh7vjc23MU8604a58JRnqLcKOkopcdd2oz9

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: cards; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cards (id, name, franchise, rarity, image_url, description, pull_count, created_at, updated_at) FROM stdin;
1	Charizard	pokemon	legendary	https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/6.png	The ultimate fire dragon Pokemon	0	2026-04-30 17:04:15.794987	2026-04-30 17:04:15.794987
2	Pikachu	pokemon	rare	https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/25.png	The iconic electric mouse Pokemon	0	2026-04-30 17:04:20.381388	2026-04-30 17:04:20.381388
3	Mewtwo	pokemon	legendary	https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/150.png	The genetic Pokemon, created by science	0	2026-04-30 17:04:24.96082	2026-04-30 17:04:24.96082
6	Dragonite	pokemon	ultra_rare	https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/149.png	The dragon Pokemon soaring the skies	0	2026-04-30 17:04:40.596209	2026-04-30 17:04:40.596209
7	Blastoise	pokemon	super_rare	https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/9.png	The shellfish Pokemon with water cannons	0	2026-04-30 17:04:45.094114	2026-04-30 17:04:45.094114
8	Venusaur	pokemon	super_rare	https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/3.png	The seed Pokemon in full bloom	0	2026-04-30 17:04:49.572726	2026-04-30 17:04:49.572726
9	Snorlax	pokemon	rare	https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/143.png	The sleeping Pokemon blocking roads	0	2026-04-30 17:04:53.856276	2026-04-30 17:04:53.856276
10	Bulbasaur	pokemon	common	https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/1.png	The seed Pokemon starter	0	2026-04-30 17:04:58.53629	2026-04-30 17:04:58.53629
11	Charmander	pokemon	common	https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/4.png	The lizard Pokemon with a burning tail	0	2026-04-30 17:05:03.493343	2026-04-30 17:05:03.493343
12	Squirtle	pokemon	common	https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/7.png	The tiny turtle Pokemon	0	2026-04-30 17:05:09.231956	2026-04-30 17:05:09.231956
13	Mew	pokemon	legendary	https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/151.png	The mythical Pokemon ancestor	0	2026-04-30 17:05:13.803302	2026-04-30 17:05:13.803302
14	Lucario	pokemon	ultra_rare	https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/448.png	The aura Pokemon fighting champion	0	2026-04-30 17:05:18.737206	2026-04-30 17:05:18.737206
15	Garchomp	pokemon	ultra_rare	https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/445.png	The mach Pokemon speed demon	0	2026-04-30 17:05:23.060058	2026-04-30 17:05:23.060058
16	Monkey D. Luffy	onepiece	legendary	https://upload.wikimedia.org/wikipedia/en/9/90/Monkey_D_Luffy.png	The future King of Pirates, Gear 5 awakened	0	2026-04-30 17:05:27.67822	2026-04-30 17:05:27.67822
17	Roronoa Zoro	onepiece	ultra_rare	https://upload.wikimedia.org/wikipedia/en/1/15/Roronoa_Zoro.png	The world's greatest swordsman in training	0	2026-04-30 17:05:32.426354	2026-04-30 17:05:32.426354
18	Trafalgar Law	onepiece	super_rare	https://i.imgur.com/placeholder-law.jpg	The Surgeon of Death with Ope-Ope no Mi	0	2026-04-30 17:05:38.191	2026-04-30 17:05:38.191
19	Portgas D. Ace	onepiece	legendary	https://i.imgur.com/placeholder-ace.jpg	The Fire Fist Ace, son of the Pirate King	0	2026-04-30 17:05:44.295967	2026-04-30 17:05:44.295967
20	Boa Hancock	onepiece	ultra_rare	https://i.imgur.com/placeholder-hancock.jpg	The Snake Princess and Pirate Empress	0	2026-04-30 17:05:48.973915	2026-04-30 17:05:48.973915
21	Nami	onepiece	rare	https://i.imgur.com/placeholder-nami.jpg	The Cat Burglar navigator of the Straw Hats	0	2026-04-30 17:05:53.476836	2026-04-30 17:05:53.476836
22	Sanji	onepiece	super_rare	https://i.imgur.com/placeholder-sanji.jpg	The Black Leg vinsmoke, Straw Hat cook	0	2026-04-30 17:05:58.260528	2026-04-30 17:05:58.260528
23	Tony Tony Chopper	onepiece	common	https://i.imgur.com/placeholder-chopper.jpg	The reindeer doctor of the Straw Hats	0	2026-04-30 17:06:02.933451	2026-04-30 17:06:02.933451
24	Nico Robin	onepiece	rare	https://i.imgur.com/placeholder-robin.jpg	The Devil Child archaeologist	0	2026-04-30 17:06:07.546278	2026-04-30 17:06:07.546278
25	Usopp	onepiece	common	https://i.imgur.com/placeholder-usopp.jpg	The brave warrior of the sea	0	2026-04-30 17:06:12.043157	2026-04-30 17:06:12.043157
26	Brook	onepiece	common	https://i.imgur.com/placeholder-brook.jpg	The Soul King musician skeleton	0	2026-04-30 17:06:16.457684	2026-04-30 17:06:16.457684
27	Shanks	onepiece	legendary	https://i.imgur.com/placeholder-shanks.jpg	Red Hair Shanks, one of the Four Emperors	0	2026-04-30 17:06:20.972833	2026-04-30 17:06:20.972833
28	Whitebeard	onepiece	legendary	https://i.imgur.com/placeholder-wb.jpg	The Strongest Man in the World	0	2026-04-30 17:06:25.401434	2026-04-30 17:06:25.401434
29	Kaido	onepiece	ultra_rare	https://i.imgur.com/placeholder-kaido.jpg	The Strongest Creature in the World	0	2026-04-30 17:06:29.946083	2026-04-30 17:06:29.946083
30	Jinbe	onepiece	super_rare	https://i.imgur.com/placeholder-jinbe.jpg	The Knight of the Sea fishman warrior	0	2026-04-30 17:06:34.307612	2026-04-30 17:06:34.307612
5	Eevee	pokemon	common	https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/133.png	The evolution Pokemon with limitless potential	1	2026-04-30 17:04:34.009898	2026-04-30 17:04:34.009898
4	Gengar	pokemon	super_rare	https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/94.png	The shadow Pokemon lurking in darkness	1	2026-04-30 17:04:29.480986	2026-04-30 17:04:29.480986
\.


--
-- Data for Name: packs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.packs (id, name, franchise, price_coins, price_usd, image_url, description, is_active, created_at, updated_at, price_idr) FROM stdin;
1	Pokemon Base Set	pokemon	100	4.99	https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/25.png	Classic Pokemon Base Set pack. Pull common to rare cards!	t	2026-04-30 17:06:54.379767	2026-04-30 17:06:54.379767	15000
2	Pokemon Legendary Pack	pokemon	500	19.99	https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/150.png	Premium pack with boosted legendary rates!	t	2026-04-30 17:06:58.916749	2026-04-30 17:06:58.916749	50000
4	One Piece Emperor Pack	onepiece	750	24.99	https://upload.wikimedia.org/wikipedia/en/1/15/Roronoa_Zoro.png	Chase the Four Emperors with ultra rare rates!	t	2026-04-30 17:07:07.850154	2026-04-30 17:07:07.850154	50000
3	One Piece Grand Line	onepiece	150	5.99	https://upload.wikimedia.org/wikipedia/en/9/90/Monkey_D_Luffy.png	Sail the Grand Line and collect Straw Hat crew cards!	t	2026-04-30 17:07:03.260627	2026-04-30 17:07:03.260627	25000
\.


--
-- Data for Name: payment_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_settings (id, key, value, updated_at) FROM stdin;
\.


--
-- Data for Name: user_balance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_balance (user_id, balance_idr, total_topup, total_spent, updated_at) FROM stdin;
1	979900	999900	20000	2026-04-30 17:38:07.161
\.


--
-- Name: cards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cards_id_seq', 30, true);


--
-- Name: packs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.packs_id_seq', 4, true);


--
-- Name: payment_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payment_settings_id_seq', 1, false);


--
-- PostgreSQL database dump complete
--

\unrestrict m4rwdk9gQKIxPt7XCcQDyJ6N1HH6Yh7vjc23MU8604a58JRnqLcKOkopcdd2oz9

